package br.mackenzie.Projeto.user;

public record LoginResponseDTO(String token) {
    
}
